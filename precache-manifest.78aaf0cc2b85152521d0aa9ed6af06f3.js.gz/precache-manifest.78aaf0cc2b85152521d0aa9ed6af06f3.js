self.__precacheManifest = [
  {
    "revision": "d15c1216957060fac577af6151fb8cfe",
    "url": "/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "9b84c8d1d2c483659db9",
    "url": "/static/js/app.3d4f89bb.chunk.js"
  },
  {
    "revision": "45a8ce76165dcaec1c5e39be15478e53",
    "url": "/static/media/robot-prod.45a8ce76.png"
  },
  {
    "revision": "6165c9d7a2e729ba57b23dd93add5366",
    "url": "/static/media/back-icon-mask.6165c9d7.png"
  },
  {
    "revision": "a30cd76fa74ee5a0bab5aba37c101416",
    "url": "/static/media/robot-dev.a30cd76f.png"
  },
  {
    "revision": "60548f17d7dc9f60a7dd",
    "url": "/static/js/runtime~app.a8a9905a.js"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/./fonts/AntDesign.ttf"
  },
  {
    "revision": "b9e61bc345a62416d1c349aab10747bd",
    "url": "/index.html"
  },
  {
    "revision": "623f6cf26f72465064c5589dab154f44",
    "url": "/manifest.json"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/serve.json"
  },
  {
    "revision": "fb608deba76b1e681d77",
    "url": "/static/js/2.832bc541.chunk.js"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/favicon.ico"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "99fc0816a09395454061301fefa42bf1",
    "url": "/./fonts/Roboto_medium.ttf"
  },
  {
    "revision": "54a91b0619ccf9373d525109268219dc",
    "url": "/./fonts/Roboto.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/./fonts/Ionicons.ttf"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/./fonts/Foundation.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/./fonts/Feather.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/./fonts/Entypo.ttf"
  }
];